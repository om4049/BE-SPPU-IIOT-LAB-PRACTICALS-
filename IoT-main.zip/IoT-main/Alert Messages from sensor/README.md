## Components: 
### Arduino UNO, Potentiometer, Jumper Wires(male to male or female to male), Bread Board.


## About the project: 
### We have created an Arduino project that generates an alert when the Potentiometer value exceeds a specified threshold.


## Debugging:
### - make sure the connections are correct.
### - make sure the pin modes are set correctly(potentiometer pin should be set to input).
### - make sure the components are not faulty.
